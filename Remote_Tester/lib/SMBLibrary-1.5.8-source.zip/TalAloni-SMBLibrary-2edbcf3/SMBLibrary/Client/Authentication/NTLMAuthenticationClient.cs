﻿/* Copyright (C) 2017-2026 Tal Aloni <tal.aloni.il@gmail.com>. All rights reserved.
 * 
 * You can redistribute this program and/or modify it under the terms of
 * the GNU Lesser Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 */
using SMBLibrary.Authentication.GSSAPI;
using SMBLibrary.Authentication.NTLM;
using System.Collections.Generic;
using Utilities;

namespace SMBLibrary.Client.Authentication
{
    public class NTLMAuthenticationClient : IAuthenticationClient
    {
        private string m_domainName;
        private string m_userName;
        private string m_password;
        private string m_spn;
        private byte[] m_sessionKey;
        private AuthenticationMethod m_authenticationMethod;
        private byte[] m_negotiateMessageBytes;

        private bool m_isNegotiationMessageAcquired = false;

        public NTLMAuthenticationClient(string domainName, string userName, string password, string spn, AuthenticationMethod authenticationMethod)
        {
            m_domainName = domainName;
            m_userName = userName;
            m_password = password;
            m_spn = spn;
            m_authenticationMethod = authenticationMethod;
        }

        public byte[] InitializeSecurityContext(byte[] securityBlob)
        {
            if (!m_isNegotiationMessageAcquired)
            {
                m_isNegotiationMessageAcquired = true;
                return GetNegotiateMessage(securityBlob);
            }
            else
            {
                return GetAuthenticateMessage(securityBlob);
            }
        }

        protected virtual byte[] GetNegotiateMessage(byte[] securityBlob)
        {
            bool useGSSAPI = false;
            if (securityBlob.Length > 0)
            {
                SimpleProtectedNegotiationTokenInit spnegoToken = null;
                try
                {
                    spnegoToken = SimpleProtectedNegotiationToken.ReadToken(securityBlob, 0, true) as SimpleProtectedNegotiationTokenInit;
                }
                catch
                {
                }

                if (spnegoToken == null || !ContainsMechanism(spnegoToken, GSSProvider.NTLMSSPIdentifier))
                {
                    return null;
                }
                useGSSAPI = true;
            }

            m_negotiateMessageBytes = CreateNegotiateMessage();
            if (useGSSAPI)
            {
                SimpleProtectedNegotiationTokenInit outputToken = new SimpleProtectedNegotiationTokenInit();
                outputToken.MechanismTypeList = new List<byte[]>();
                outputToken.MechanismTypeList.Add(GSSProvider.NTLMSSPIdentifier);
                outputToken.MechanismToken = m_negotiateMessageBytes;
                return outputToken.GetBytes(true);
            }
            else
            {
                return m_negotiateMessageBytes;
            }
        }

        protected virtual byte[] CreateNegotiateMessage()
        {
            return NTLMAuthenticationHelper.GetNegotiateMessage(m_userName, m_password, m_authenticationMethod);
        }

        protected virtual byte[] GetAuthenticateMessage(byte[] securityBlob)
        {
            bool useGSSAPI = false;
            SimpleProtectedNegotiationTokenResponse spnegoToken = null;
            try
            {
                spnegoToken = SimpleProtectedNegotiationToken.ReadToken(securityBlob, 0, false) as SimpleProtectedNegotiationTokenResponse;
            }
            catch
            {
            }

            byte[] challengeMessageBytes;
            if (spnegoToken != null)
            {
                challengeMessageBytes = spnegoToken.ResponseToken;
                useGSSAPI = true;
            }
            else
            {
                challengeMessageBytes = securityBlob;
            }

            byte[] authenticateMessageBytes = NTLMAuthenticationHelper.GetAuthenticateMessage(m_negotiateMessageBytes, challengeMessageBytes, m_domainName, m_userName, m_password, m_spn, m_authenticationMethod, out m_sessionKey);
            if (useGSSAPI && authenticateMessageBytes != null)
            {
                SimpleProtectedNegotiationTokenResponse outputToken = new SimpleProtectedNegotiationTokenResponse();
                outputToken.ResponseToken = authenticateMessageBytes;
                List<byte[]> mechanismTypeList = new List<byte[]>() { GSSProvider.NTLMSSPIdentifier };
                byte[] mechListBytes = SimpleProtectedNegotiationTokenInit.GetMechanismTypeListBytes(mechanismTypeList);
                outputToken.MechanismListMIC = NTLMCryptography.ComputeMechListMIC(m_sessionKey, mechListBytes);
                return outputToken.GetBytes();
            }
            else
            {
                return authenticateMessageBytes;
            }
        }

        public virtual byte[] GetSessionKey()
        {
            return m_sessionKey;
        }

        public virtual void ResetSecurityContext(string spn)
        {
            m_spn = spn;
            m_isNegotiationMessageAcquired = false;
            m_negotiateMessageBytes = null;
            m_sessionKey = null;
        }

        private static bool ContainsMechanism(SimpleProtectedNegotiationTokenInit token, byte[] mechanismIdentifier)
        {
            for (int index = 0; index < token.MechanismTypeList.Count; index++)
            {
                if (ByteUtils.AreByteArraysEqual(token.MechanismTypeList[index], mechanismIdentifier))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
