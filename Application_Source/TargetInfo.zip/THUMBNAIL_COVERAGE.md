# Hybrid essentials projection

This build ships 199 credited essential image assignments. The following upstream inventory describes the full reviewed source set; additional reviewed mappings are retained in InformationMedia.json for on-demand enrichment. Essentials hashes, exact credits, licences and resizing/black-matte modifications are recorded in essentials.json. Catalogue identities and acknowledgements remain intact.

# Thumbnail coverage — package 2.1.0

Prepared 11 October 2026; data release `2026.10.11.2`; database schema remains `2.0.0`.

**325 target cards have approved offline thumbnails**, up from 16. They use **314 distinct local image files**, totalling **44,924,431 bytes** (42.84 MiB). Shared photographs are reused only with explicit context labels, without collapsing entity identities.

The explicit popular-target working list contains **314 targets**, with **314 covered** and **0 gaps**. It includes all **109 undisputed Messier records**, the **NGC5866 candidate for M102**, all **109 Caldwell designations**, the handoff's curated non-stellar deep-sky targets and the Sun. M102's historical record remains disputed and has no unqualified identity/image assertion; its candidate card has an image. The original 11 Solar System images outside this working list are also preserved. "Popular" is not a universal closed catalogue: this release documents an explicit broad working list and can be extended with further named targets.

Included targets span major galaxies, open/globular clusters, planetary nebulae, emission/reflection/dark nebulae and supernova remnants. Examples include Horsehead, Heart/Soul, Elephant's Trunk, North America/Pelican, Rosette, Eastern/Western Veil, Bubble, Crescent, Iris, California, Carina, Helix, Thor's Helmet, Wizard, Jellyfish, Monkey Head, Lion, Spaghetti, Flying Bat/Squid, Dark Shark, Rotten Fish, Medusa and Jones–Emberson1.

## Licence inventory

| Exact licence | Target-card assignments |
|---|---:|
| CC-BY-2.0 | 23 |
| CC-BY-2.5 | 1 |
| CC-BY-3.0 | 15 |
| CC-BY-4.0 | 95 |
| CC-BY-SA-2.0 | 5 |
| CC-BY-SA-2.5 | 4 |
| CC-BY-SA-3.0 | 25 |
| CC-BY-SA-3.0-US | 7 |
| CC-BY-SA-4.0 | 61 |
| CC0-1.0 | 39 |
| Public domain | 50 |

Every assignment has exact source/file-page and media/thumbnail URLs, creator/full credit, licence and licence URL, verification date, local path, SHA-256, byte count/dimensions/MIME and representation/subject notes. `source/thumbnail_review_evidence.json` records the expansion's individual file licence decisions; the original 16 retain `source/image_licence_evidence.json`. Licence and credit obligations travel with each image, including older/ported CC licences. CC BY-SA is not interchangeable with CC0 or public domain. NASA/ESA/NOIRLab hosting alone never establishes permission. Current ESA/Hubble terms were checked at https://esahubble.org/copyright/ and explicit CC BY4 conditions retained where legacy public-domain tags were less clear.

Candidate discovery used linked catalogue articles and exact-name Commons searches. Candidates were screened for reusable rights and inspected as actual thumbnails. Charts, simulated skies, unrelated names and unsuitable crops were rejected. The image of a car named IC10, London night lights for M25, a one-cluster Double Cluster view, a Hyades finder chart, a Stellarium view and a Barnard35/Raspberry view for the full Lambda Orionis Ring were excluded. A weak M61 frame and a dust-dominated NGC188 view were replaced. The new images are observations, not generated depictions.

Some cards deliberately show wider context or partial extents: IC59/IC63 share a field; Antennae and Double Cluster components share relevant views; NGC2237 uses a labelled Rosette context image; Eastern Veil uses a labelled NGC6992 portion; North America/Pelican uses their combined field. These are photographic context assignments, not aliases or scientific identity merges. Infrared/ultraviolet/multiwavelength/narrowband images are labelled where verified; otherwise filter/colour processing is stated as unspecified, never advertised as true colour. The Sun has a full-disk white-light image from SDO's Helioseismic and Magnetic Imager (2026). NGC6995 uses an annotated GALEX observational image locating its component in the Cygnus Loop.

No increase in scientific prose review is claimed: the existing 14 checked rich cards and remaining draft content retain their earlier review statuses. This is an image coverage update.

## Per-target coverage

The complete machine-readable list, including Messier and Caldwell accounting, is `data/thumbnail_coverage.json`.

| Object ID | Target | Image status |
|---|---|---|
| ABELL 21 | Medusa Nebula | approved_local |
| ABELL 31 | Abell 31 | approved_local |
| ABELL 39 | Abell 39 | approved_local |
| ABELL 85 | CTB 1 | approved_local |
| ARP 244 | Antennae Galaxies | approved_local |
| ARP 271 | NGC 5426/NGC 5427 pair | approved_local |
| B 168 | Barnard 168 | approved_local |
| B 33 | Horsehead Nebula | approved_local |
| B 68 | Barnard 68 | approved_local |
| B 72 | Snake Nebula | approved_local |
| C 14 | Double Cluster | approved_local |
| C041 | C041 | approved_local |
| C099 | C099 | approved_local |
| IC 10 | IC 10 | approved_local |
| IC 1396 | IC 1396 | approved_local |
| IC 1396A | Elephant's Trunk Nebula | approved_local |
| IC 1613 | IC 1613 | approved_local |
| IC 1805 | Heart Nebula | approved_local |
| IC 1848 | Soul Nebula | approved_local |
| IC 2118 | Witch Head Nebula | approved_local |
| IC 2163 | IC 2163 | approved_local |
| IC 2391 | IC 2391 | approved_local |
| IC 2602 | IC 2602 | approved_local |
| IC 2944 | Running Chicken Nebula | approved_local |
| IC 342 | Hidden Galaxy | approved_local |
| IC 405 | Flaming Star Nebula | approved_local |
| IC 410 | Tadpoles Nebula | approved_local |
| IC 417 | Spider Nebula | approved_local |
| IC 443 | Jellyfish Nebula | approved_local |
| IC 4592 | Blue Horsehead Nebula | approved_local |
| IC 4604 | Rho Ophiuchi Nebula | approved_local |
| IC 5070 | Pelican Nebula | approved_local |
| IC 5146 | Cocoon Nebula | approved_local |
| IC 59 | IC 59 | approved_local |
| IC 63 | Ghost of Cassiopeia | approved_local |
| LBN 437 | LBN 437 | approved_local |
| LDN 1235 | Dark Shark Nebula | approved_local |
| LDN 1251 | LDN 1251 | approved_local |
| LDN 1622 | Boogeyman Nebula | approved_local |
| LMC | Large Magellanic Cloud | approved_local |
| M1 | Crab Nebula | approved_local |
| M10 | Messier 10 | approved_local |
| M100 | Messier 100 | approved_local |
| M101 | Pinwheel Galaxy | approved_local |
| M103 | Messier 103 | approved_local |
| M104 | Sombrero Galaxy | approved_local |
| M105 | Messier 105 | approved_local |
| M106 | Messier 106 | approved_local |
| M107 | Messier 107 | approved_local |
| M108 | Surfboard Galaxy | approved_local |
| M109 | Messier 109 | approved_local |
| M11 | Wild Duck Cluster | approved_local |
| M110 | Messier 110 | approved_local |
| M12 | Messier 12 | approved_local |
| M13 | Great Hercules Cluster | approved_local |
| M14 | Messier 14 | approved_local |
| M15 | Great Pegasus Cluster | approved_local |
| M16 | Eagle Nebula | approved_local |
| M17 | Omega Nebula | approved_local |
| M18 | Messier 18 | approved_local |
| M19 | Messier 19 | approved_local |
| M2 | Messier 2 | approved_local |
| M20 | Trifid Nebula | approved_local |
| M21 | Messier 21 | approved_local |
| M22 | Sagittarius Cluster | approved_local |
| M23 | Messier 23 | approved_local |
| M24 | Sagittarius Star Cloud | approved_local |
| M25 | Messier 25 | approved_local |
| M26 | Messier 26 | approved_local |
| M27 | Dumbbell Nebula | approved_local |
| M28 | Messier 28 | approved_local |
| M29 | Messier 29 | approved_local |
| M3 | Messier 3 | approved_local |
| M30 | Messier 30 | approved_local |
| M31 | Andromeda Galaxy | approved_local |
| M32 | Messier 32 | approved_local |
| M33 | Triangulum Galaxy | approved_local |
| M34 | Messier 34 | approved_local |
| M35 | Messier 35 | approved_local |
| M36 | Pinwheel Cluster | approved_local |
| M37 | Messier 37 | approved_local |
| M38 | Starfish Cluster | approved_local |
| M39 | Messier 39 | approved_local |
| M4 | Messier 4 | approved_local |
| M40 | Winnecke 4 | approved_local |
| M41 | Messier 41 | approved_local |
| M42 | Orion Nebula | approved_local |
| M43 | De Mairan's Nebula | approved_local |
| M44 | Beehive Cluster | approved_local |
| M45 | Pleiades | approved_local |
| M46 | Messier 46 | approved_local |
| M47 | Messier 47 | approved_local |
| M48 | Messier 48 | approved_local |
| M49 | Messier 49 | approved_local |
| M5 | Messier 5 | approved_local |
| M50 | Heart-Shaped Cluster | approved_local |
| M51 | Whirlpool Galaxy | approved_local |
| M52 | Messier 52 | approved_local |
| M53 | Messier 53 | approved_local |
| M54 | Messier 54 | approved_local |
| M55 | Messier 55 | approved_local |
| M56 | Messier 56 | approved_local |
| M57 | Ring Nebula | approved_local |
| M58 | Messier 58 | approved_local |
| M59 | Messier 59 | approved_local |
| M6 | Butterfly Cluster | approved_local |
| M60 | Messier 60 | approved_local |
| M61 | Messier 61 | approved_local |
| M62 | Messier 62 | approved_local |
| M63 | Sunflower Galaxy | approved_local |
| M64 | Black Eye Galaxy | approved_local |
| M65 | Messier 65 | approved_local |
| M66 | Messier 66 | approved_local |
| M67 | Messier 67 | approved_local |
| M68 | Messier 68 | approved_local |
| M69 | Messier 69 | approved_local |
| M7 | Ptolemy Cluster | approved_local |
| M70 | Messier 70 | approved_local |
| M71 | Messier 71 | approved_local |
| M72 | Messier 72 | approved_local |
| M73 | Messier 73 | approved_local |
| M74 | Phantom Galaxy | approved_local |
| M75 | Messier 75 | approved_local |
| M76 | Little Dumbbell Nebula | approved_local |
| M77 | Messier 77 | approved_local |
| M78 | Messier 78 | approved_local |
| M79 | Messier 79 | approved_local |
| M8 | Lagoon Nebula | approved_local |
| M80 | Messier 80 | approved_local |
| M81 | Bode's Galaxy | approved_local |
| M82 | Cigar Galaxy | approved_local |
| M83 | Southern Pinwheel Galaxy | approved_local |
| M84 | Messier 84 | approved_local |
| M85 | Messier 85 | approved_local |
| M86 | Messier 86 | approved_local |
| M87 | Messier 87 | approved_local |
| M88 | Messier 88 | approved_local |
| M89 | Messier 89 | approved_local |
| M9 | Messier 9 | approved_local |
| M90 | Messier 90 | approved_local |
| M91 | Messier 91 | approved_local |
| M92 | Messier 92 | approved_local |
| M93 | Messier 93 | approved_local |
| M94 | Messier 94 | approved_local |
| M95 | Messier 95 | approved_local |
| M96 | Messier 96 | approved_local |
| M97 | Owl Nebula | approved_local |
| M98 | Messier 98 | approved_local |
| M99 | Coma Pinwheel | approved_local |
| NGC 104 | NGC 104 | approved_local |
| NGC 1097 | NGC 1097 | approved_local |
| NGC 1261 | NGC 1261 | approved_local |
| NGC 1275 | NGC 1275 | approved_local |
| NGC 1313 | NGC 1313 | approved_local |
| NGC 1333 | NGC 1333 | approved_local |
| NGC 1365 | Great Barred Spiral Galaxy | approved_local |
| NGC 147 | NGC 147 | approved_local |
| NGC 1499 | California Nebula | approved_local |
| NGC 1566 | Spanish Dancer Galaxy | approved_local |
| NGC 1579 | Northern Trifid Nebula | approved_local |
| NGC 1672 | NGC 1672 | approved_local |
| NGC 185 | NGC 185 | approved_local |
| NGC 1851 | NGC 1851 | approved_local |
| NGC 188 | NGC 188 | approved_local |
| NGC 2024 | Flame Nebula | approved_local |
| NGC 2070 | Tarantula Nebula | approved_local |
| NGC 2158 | NGC 2158 | approved_local |
| NGC 2174 | Monkey Head Nebula | approved_local |
| NGC 2237 | NGC 2237 (Rosette A) | approved_local |
| NGC 2244 | Rosette Cluster | approved_local |
| NGC 2261 | NGC 2261 | approved_local |
| NGC 2264 | Christmas Tree Cluster | approved_local |
| NGC 2359 | Thor's Helmet | approved_local |
| NGC 2360 | NGC 2360 | approved_local |
| NGC 2362 | NGC 2362 | approved_local |
| NGC 2392 | NGC 2392 | approved_local |
| NGC 2403 | NGC 2403 | approved_local |
| NGC 2419 | NGC 2419 | approved_local |
| NGC 2438 | NGC 2438 | approved_local |
| NGC 246 | NGC 246 | approved_local |
| NGC 2467 | Skull and Crossbones Nebula | approved_local |
| NGC 247 | NGC 247 | approved_local |
| NGC 2477 | NGC 2477 | approved_local |
| NGC 2506 | NGC 2506 | approved_local |
| NGC 2516 | NGC 2516 | approved_local |
| NGC 253 | Sculptor Galaxy | approved_local |
| NGC 2736 | Pencil Nebula | approved_local |
| NGC 2775 | NGC 2775 | approved_local |
| NGC 281 | Pacman Nebula | approved_local |
| NGC 2818 | NGC 2818 | approved_local |
| NGC 2867 | NGC 2867 | approved_local |
| NGC 300 | NGC 300 | approved_local |
| NGC 3115 | NGC 3115 | approved_local |
| NGC 3132 | NGC 3132 | approved_local |
| NGC 3195 | NGC 3195 | approved_local |
| NGC 3199 | NGC 3199 | approved_local |
| NGC 3201 | NGC 3201 | approved_local |
| NGC 3242 | Ghost of Jupiter | approved_local |
| NGC 3324 | Gabriela Mistral Nebula | approved_local |
| NGC 3372 | Carina Nebula | approved_local |
| NGC 346 | NGC 346 | approved_local |
| NGC 3532 | NGC 3532 | approved_local |
| NGC 3576 | Statue of Liberty Nebula | approved_local |
| NGC 3603 | NGC 3603 | approved_local |
| NGC 362 | NGC 362 | approved_local |
| NGC 3626 | NGC 3626 | approved_local |
| NGC 3628 | Hamburger Galaxy | approved_local |
| NGC 3766 | NGC 3766 | approved_local |
| NGC 40 | NGC 40 | approved_local |
| NGC 4038 | NGC 4038 | approved_local |
| NGC 4039 | NGC 4039 | approved_local |
| NGC 4236 | NGC 4236 | approved_local |
| NGC 4244 | NGC 4244 | approved_local |
| NGC 4372 | NGC 4372 | approved_local |
| NGC 4449 | NGC 4449 | approved_local |
| NGC 4559 | NGC 4559 | approved_local |
| NGC 4565 | Needle Galaxy | approved_local |
| NGC 457 | NGC 457 | approved_local |
| NGC 4609 | NGC 4609 | approved_local |
| NGC 4631 | Whale Galaxy | approved_local |
| NGC 4656 | Hockey Stick Galaxy | approved_local |
| NGC 4697 | NGC 4697 | approved_local |
| NGC 4725 | NGC 4725 | approved_local |
| NGC 4755 | NGC 4755 | approved_local |
| NGC 4833 | NGC 4833 | approved_local |
| NGC 4889 | NGC 4889 | approved_local |
| NGC 4945 | NGC 4945 | approved_local |
| NGC 5005 | NGC 5005 | approved_local |
| NGC 5128 | Centaurus A | approved_local |
| NGC 5139 | Omega Centauri | approved_local |
| NGC 5195 | NGC 5195 | approved_local |
| NGC 5248 | NGC 5248 | approved_local |
| NGC 5286 | NGC 5286 | approved_local |
| NGC 5426 | NGC 5426 | approved_local |
| NGC 5427 | NGC 5427 | approved_local |
| NGC 55 | NGC 55 | approved_local |
| NGC 559 | NGC 559 | approved_local |
| NGC 5694 | NGC 5694 | approved_local |
| NGC 5823 | NGC 5823 | approved_local |
| NGC 5866 | NGC 5866 | approved_local |
| NGC 5907 | Splinter Galaxy | approved_local |
| NGC 6025 | NGC 6025 | approved_local |
| NGC 604 | NGC 604 | approved_local |
| NGC 6087 | NGC 6087 | approved_local |
| NGC 6101 | NGC 6101 | approved_local |
| NGC 6124 | NGC 6124 | approved_local |
| NGC 6188 | Fighting Dragons of Ara | approved_local |
| NGC 6193 | NGC 6193 | approved_local |
| NGC 6231 | Northern Jewel Box | approved_local |
| NGC 6302 | Butterfly Nebula | approved_local |
| NGC 6334 | Cat's Paw Nebula | approved_local |
| NGC 6352 | NGC 6352 | approved_local |
| NGC 6357 | Lobster Nebula | approved_local |
| NGC 6397 | NGC 6397 | approved_local |
| NGC 6541 | NGC 6541 | approved_local |
| NGC 6543 | Cat's Eye Nebula | approved_local |
| NGC 6604 | NGC 6604 | approved_local |
| NGC 663 | NGC 663 | approved_local |
| NGC 6726 | NGC 6726 | approved_local |
| NGC 6729 | NGC 6729 | approved_local |
| NGC 6744 | NGC 6744 | approved_local |
| NGC 6752 | NGC 6752 | approved_local |
| NGC 6781 | NGC 6781 | approved_local |
| NGC 6822 | Barnard's Galaxy | approved_local |
| NGC 6826 | Blinking Planetary | approved_local |
| NGC 6882 | NGC 6882 | approved_local |
| NGC 6888 | Crescent Nebula | approved_local |
| NGC 6914 | NGC 6914 | approved_local |
| NGC 6934 | NGC 6934 | approved_local |
| NGC 6946 | Fireworks Galaxy | approved_local |
| NGC 6960 | Western Veil Nebula | approved_local |
| NGC 6979 | Pickering's Triangle | approved_local |
| NGC 6992 | NGC 6992 | approved_local |
| NGC 6995 | NGC 6995 | approved_local |
| NGC 7000 | North America Nebula | approved_local |
| NGC 7006 | NGC 7006 | approved_local |
| NGC 7009 | Saturn Nebula | approved_local |
| NGC 7023 | Iris Nebula | approved_local |
| NGC 7027 | NGC 7027 | approved_local |
| NGC 7243 | NGC 7243 | approved_local |
| NGC 7293 | Helix Nebula | approved_local |
| NGC 7331 | NGC 7331 | approved_local |
| NGC 7380 | NGC 7380 cluster | approved_local |
| NGC 7479 | NGC 7479 | approved_local |
| NGC 752 | NGC 752 | approved_local |
| NGC 7635 | Bubble Nebula | approved_local |
| NGC 7662 | NGC 7662 | approved_local |
| NGC 7814 | NGC 7814 | approved_local |
| NGC 7822 | NGC 7822 | approved_local |
| NGC 869 | Double Cluster h Persei | approved_local |
| NGC 884 | Double Cluster chi Persei | approved_local |
| NGC 891 | NGC 891 | approved_local |
| OU4 | Squid Nebula | approved_local |
| PK 164+31.1 | Jones-Emberson 1 | approved_local |
| ROSETTE | Rosette Nebula complex | approved_local |
| SH2-101 | Tulip Nebula | approved_local |
| SH2-106 | Sh2-106 | approved_local |
| SH2-112 | Sh2-112 | approved_local |
| SH2-117 | North America-Pelican complex | approved_local |
| SH2-119 | Clamshell Nebula | approved_local |
| SH2-129 | Flying Bat Nebula | approved_local |
| SH2-132 | Lion Nebula | approved_local |
| SH2-142 | Wizard Nebula | approved_local |
| SH2-155 | Cave Nebula | approved_local |
| SH2-157 | Lobster Claw Nebula | approved_local |
| SH2-240 | Spaghetti Nebula | approved_local |
| SH2-261 | Lower's Nebula | approved_local |
| SH2-264 | Lambda Orionis Ring | approved_local |
| SH2-276 | Barnard's Loop | approved_local |
| SH2-308 | Dolphin Head Nebula | approved_local |
| SMC | Small Magellanic Cloud | approved_local |
| VEIL-EAST | Eastern Veil Nebula | approved_local |
| vdB 152 | Wolf's Cave Nebula | approved_local |
| SUN | Sun | approved_local |
