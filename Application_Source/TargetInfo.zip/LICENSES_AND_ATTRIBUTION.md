# Redistribution inventory

## OpenNGC

The imported OpenNGC dataset and adapted catalogue information are CC BY-SA 4.0. Credit OpenNGC contributors, led by Mattia Verga, link https://github.com/mattiaverga/OpenNGC and https://creativecommons.org/licenses/by-sa/4.0/, identify this catalogue merge and field/identity mappings as adaptations, and retain the licence. Full licence text is in `source/upstream/CC-BY-SA-4.0.txt`; upstream field documentation, AUTHORS and acknowledgements are retained. Snapshot commit: `4e2398a263de663d83f7b86be80c368c34335764`. Dataset version, dates, hashes and mapping rules are in `source/provenance.json` and the SQLite `dataset` table. Do not assume a proprietary application licence replaces share-alike obligations on the adapted dataset.

Retain OpenNGC's source acknowledgements:

- This research has made use of the NASA/IPAC Extragalactic Database (NED), operated by the Jet Propulsion Laboratory, California Institute of Technology, under contract with NASA.
- We acknowledge the usage of the HyperLeda database (http://leda.univ-lyon1.fr).
- This research has made use of the SIMBAD database, operated at CDS, Strasbourg, France.
- OpenNGC used HEASARC databases and Harold Corwin's NGC/IC Positions and Notes. See the full upstream README for links and details.

## Editorial content and Python code

The original handoff provides original AstroArchive prose and scripts but no explicit public code/text licence. They are preserved as user-supplied material for this project; this delivery does not invent an open licence for those originals. The programme owner should establish the distribution licence for its editorial/code component. New NASA-derived prose is independently written from cited facts, not copied page text. NASA source HTML is not bundled. Catalogue-derived basic descriptions/measurements and identity cross-IDs retain OpenNGC's CC BY-SA terms.

## Images

`source/approved_images.json` and `data/approved_images.json` list every bundled file with creator, credit, original page/media URL, individual licence URL, verification date, processing/representation, local checksum and dimensions. `source/image_licence_evidence.json` preserves the relevant Commons file-page licence templates and metadata checked on 2026-10-11.

The original four CC0 and twelve NASA public-domain assets are preserved. The expanded set has 325 target assignments over 314 distinct files, using individually verified CC0, CC BY, CC BY-SA and public-domain permissions. Exact versions and ported variants are recorded per image; see `THUMBNAIL_COVERAGE.md` for counts. Share-alike applies to those images, including resized/format-converted thumbnails, without replacing the source licence with the programme licence. Source credits and scientific collaborators remain credited. NASA status is based on each file page, not a blanket assertion that all NASA-hosted media is public domain. Jupiter's Kevin M. Gill processing credit is retained. Neither NASA endorsement nor permission to use NASA logos is implied. Review the actual licence and source page again before replacing an asset. NASA guidance: https://www.nasa.gov/nasa-brand-center/images-and-media/.

The 16 original links are also retained as historical unverified candidates; only the approved manifest authorises this release's assets. Processing/wavelength labels matter: M33 is an infrared false-colour composite; Venus is a radar-based rendering; Mars has a synthesised colour channel. None of these is labelled an ordinary optical true-colour photograph.

## Sources reviewed but not redistributed

The Astronomical League Caldwell HTML, prose, positions and measured table are not bundled; only its identity/region definitions were checked against the licensed OpenNGC cross-IDs. Sharpless VII/20 and Lynds VII/7A source documentation was inspected at CDS, along with https://cds.unistra.fr/vizier-org/licences_vizier.html. Those rules give scientific usage guidance and require source-dependent checks for commercial usage; service access alone does not establish unrestricted application redistribution. No full CDS catalogue data or metadata is included. The Barnard catalogue itself was not acquired. A full Sharpless/LDN/Barnard import requires an individually documented reusable source or appropriate permission. Do not infer permission from a NASA/CDS search endpoint being public.

## Expanded image review (package 2.1.0)

`source/thumbnail_review_evidence.json` records the expansion's individually checked file pages, licence templates and explicit context decisions. The current ESA/Hubble policy at https://esahubble.org/copyright/ was inspected: published images are reusable under CC BY4 with full, unaltered credit and active links where online, without implying endorsement. For ESA-served images carrying a less explicit legacy Commons PD-Hubble tag, the manifest conservatively retains the current agency's CC BY4 credit conditions. This is a recorded source-terms decision, not a blanket declaration that ESA or all Hubble imagery is public domain. No logos, simulations or unlicensed high-resolution gallery alternatives were bundled. NSF/NOIRLab/DSS/2MASS permissions and author-created CC images are checked per file; a service being accessible is not a licence. Metadata does not promote any scientific prose review status.

The included 2MASS images retain acknowledgement to 2MASS/UMass/IPAC-Caltech/NASA/NSF. Where an Adam Block source offers only its gallery/file version for reuse and reserves larger alternatives, only that licensed Commons file's thumbnail was fetched; the restriction is retained in modification notes. Credits include original photography/processing names, rather than simply naming an uploader or host. Linked article page images are discovery leads; Wikimedia non-free illustrations and author impressions do not qualify automatically.
